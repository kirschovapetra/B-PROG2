#include <stdio.h>
#include <stdlib.h>
#include "banka.h"

int main() {
	cislo_uctu_t ucet;
	suma_t peniaze_u_klienta = 1000;
	
	ucet = novy_ucet();
	printf("Klient si zalozil novy ucet, cislo: %08i\n", ucet);
	printf("U klienta : %6i zlatych\n", peniaze_u_klienta);
	printf("Na ucte je: %6i zlatych\n", stav(ucet));
	system("pause");	
	
	platba(ucet, &peniaze_u_klienta, 100);
	printf("\nVlozili sme peniaze:\n");
	printf("U klienta : %6i zlatych\n", peniaze_u_klienta);
	printf("Na ucte je: %6i zlatych\n", stav(ucet));
	system("pause");	

	platba(&peniaze_u_klienta, ucet, 50);
	printf("\nVybrali sme peniaze:\n");
	printf("U klienta : %6i zlatych\n", peniaze_u_klienta);
	printf("Na ucte je: %6i zlatych\n", stav(ucet));
	system("pause");	
	
	zavri_ucet(ucet);
		
	return 0;
}
