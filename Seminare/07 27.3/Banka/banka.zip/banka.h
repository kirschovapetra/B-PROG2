#ifndef _BANKA_H
#define _BANKA_H

typedef int suma_t;
typedef int* cislo_uctu_t;

//zaloz ucet, vrati cislo uctu
cislo_uctu_t novy_ucet();

//zisti stav uctu, vrati sumu penazi na ucte
suma_t stav(cislo_uctu_t ucet);

//presunie peniaze z jedneho uctu na druhy (ak tam je dost), vrati, ci sa transakcia mohla vykonat
int platba(cislo_uctu_t kam, cislo_uctu_t odkial, suma_t suma);

suma_t zavri_ucet(cislo_uctu_t ucet);

#endif
