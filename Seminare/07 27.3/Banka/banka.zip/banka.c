#include "banka.h"
#include <stdlib.h>

//zaloz ucet, vrati cislo uctu
cislo_uctu_t novy_ucet()
{
	return (cislo_uctu_t) malloc(sizeof(suma_t));   
}

//zisti stav uctu, vrati sumu penazi na ucte
suma_t stav(cislo_uctu_t ucet)
{
	return *ucet;
}

//pridaj nejaku sumu penazi na nejaky ucet, vrati vlozenu sumu
suma_t vklad(cislo_uctu_t ucet, suma_t suma)
{
	if (suma > 0)
	{
		*ucet += suma;
		return suma;
	}
	return 0;
}
//vyber nejaku sumu penazi na nejaky ucet, vrati vybranu sumu
suma_t vyber(cislo_uctu_t ucet, suma_t suma)
{
	if (suma > 0 && suma <= stav(ucet))
	{
		*ucet -= suma;
		return suma;	
	}
	return 0;
}

int platba(cislo_uctu_t kam, cislo_uctu_t odkial, suma_t suma)
{
	return vklad(kam, vyber(odkial, suma));
}

suma_t zavri_ucet(cislo_uctu_t ucet)
{
	suma_t tmp = *ucet;
	free(ucet);
	return tmp;
}

